<?php

use ImproveSEO\View;

function improveseo_keyword_generator() {
	View::render('features.keyword');
}
