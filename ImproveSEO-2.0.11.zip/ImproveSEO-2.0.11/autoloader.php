<?php

include_once 'includes/ImproveSEO/Autoloader.php';

new ImproveSEO\Autoloader();

session_start();