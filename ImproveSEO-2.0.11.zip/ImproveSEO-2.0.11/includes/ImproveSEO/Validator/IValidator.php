<?php

namespace ImproveSEO\Validator;

interface IValidator
{
	public static function validate($data, $field);
}