<?php

namespace ImproveSEO\Validator;

class ValidatorException extends \Exception {}