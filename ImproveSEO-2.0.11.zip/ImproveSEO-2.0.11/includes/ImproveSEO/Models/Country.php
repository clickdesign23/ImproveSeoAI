<?php

namespace ImproveSEO\Models;

class Country extends AbstractModel
{
	protected $fillable = array('name', 'short');
}